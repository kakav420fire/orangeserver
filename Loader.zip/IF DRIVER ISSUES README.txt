1.
If the driver cant connect make sure you go to the assets/ folder and delete these files: "kdmapper_Release.exe","driver.sys".

2.
Then unzip the "MANUAL.zip" file and drag the "driver.sys" file into the "kdmapper_Release.exe" file.

3.
Then restart the loader, and ur good to go! :D